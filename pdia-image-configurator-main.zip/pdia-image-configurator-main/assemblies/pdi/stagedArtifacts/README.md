Here you need to copy the pentaho distribution software ZIP files

examples
- pdi-ee-client-11.0.0.0-xxx.zip

