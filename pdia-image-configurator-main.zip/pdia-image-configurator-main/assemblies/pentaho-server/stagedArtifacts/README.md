Here you need to copy the pentaho distribution software ZIP files

examples
- pentaho-server-ee-11.0.0.0-xxx.zip
- paz-plugin-ee-11.0.0.0-xxx.zip
- pir-plugin-ee-11.0.0.0-xxx.zip
- pdd-plugin-ee-11.0.0.0-xxx.zip

